package de.ecspride;

public abstract class BaseClass {
	
	public String imei;
	
	public abstract String foo();

}
