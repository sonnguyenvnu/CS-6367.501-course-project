package de.ecspride;


public abstract class General {

	public abstract String getInfo();
	public abstract String getInfoMultiTaint();
}
