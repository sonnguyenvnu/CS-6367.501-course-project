package de.ecspride;

public class ConcreteClass extends BaseClass {

	@Override
	public String foo() {
		return imei;
	}
	
}
