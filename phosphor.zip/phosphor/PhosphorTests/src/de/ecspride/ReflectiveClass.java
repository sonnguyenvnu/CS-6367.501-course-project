package de.ecspride;

public class ReflectiveClass {
	
	private String imei = "";
	
	public void setImei(String imei) {
		this.imei = imei;
	}
	
	public String getImei() {
		return this.imei;
	}

}
