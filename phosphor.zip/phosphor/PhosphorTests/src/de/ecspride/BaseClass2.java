package de.ecspride;

public abstract class BaseClass2 {
	
	public abstract String foo();
	
	public abstract void bar(String s);

	
	public abstract String fooMultiTaint();
	
	public abstract void barMultiTaint(String s);

}
