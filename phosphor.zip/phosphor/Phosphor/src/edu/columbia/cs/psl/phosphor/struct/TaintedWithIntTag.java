package edu.columbia.cs.psl.phosphor.struct;

public interface TaintedWithIntTag extends Tainted {
	public int getPHOSPHOR_TAG();
	public void setPHOSPHOR_TAG(int i);
}
