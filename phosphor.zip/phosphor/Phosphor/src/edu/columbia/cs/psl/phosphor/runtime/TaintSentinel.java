package edu.columbia.cs.psl.phosphor.runtime;

public class TaintSentinel {

}
