package edu.columbia.cs.psl.phosphor.instrumenter.asm;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Label;


public class OffsetPreservingClassReader extends ClassReader {

	public OffsetPreservingClassReader(byte[] b) {
		super(b);
	}

	@Override
	protected Label readLabel(int offset, Label[] labels) {
		if (labels[offset] == null) {
			for(int i = 0; i < labels.length;i++)
				labels[i] = new OffsetPreservingLabel(i);
        }
        return labels[offset];
	}
	
}
