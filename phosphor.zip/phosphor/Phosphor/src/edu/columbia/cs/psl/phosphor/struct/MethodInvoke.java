package edu.columbia.cs.psl.phosphor.struct;

import java.lang.reflect.Method;

public class MethodInvoke {
	public Method m ;
	public Object o;
	public Object[] a;
}
