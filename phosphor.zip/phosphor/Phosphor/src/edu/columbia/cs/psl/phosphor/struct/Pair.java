package edu.columbia.cs.psl.phosphor.struct;

public class Pair {
	public Class o0;
	public String o1;
	public Class[] o2;
}
