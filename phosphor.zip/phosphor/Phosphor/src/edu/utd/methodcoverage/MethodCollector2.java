package edu.utd.methodcoverage;

import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

/**
 * MethodCollector (is a MethodVisitor) collect all methods' information in a
 * project
 * 
 * @author sonnguyen
 *
 */
class MethodCollector2 extends MethodVisitor implements Opcodes {
	private static final boolean TAIN_OBJECT = true;
	String mName;
	String desc;
	String taintedMethod;
	String taintedMethodDesc;
	/**
	 * temporary storage the value of recent VarInst, to create a new local
	 * variable
	 */
	int tempVar;
	/** increasing the number of local variables */
	int tempLocal;
	/** increasing the number of stacks */
	int tempStack;
	/** the recent field accessed */
	String fieldName;
	/** the owner of recent field accessed */
	String fieldOwner;
	/** */
	String fieldDesc;
	/** check return a field */
	boolean isFieldAccess = false;
	/** check return value is a static variable */
	boolean isFieldStatic = false;
	/** check return NULL */// <--- Can generalize to return a const
	boolean returnNull = false;
	/** check return by new operator. eg. return new ClsName() */
	boolean returnNewInstance = false;
	// Not handle the ternary operator in return statement "return (b? e1:e2);"
	// TODO: syntactically modify this statement to "if(b) return e1 else return
	// e2;"
	boolean ternary = false;
	/** check return an element of a array */
	boolean returnArrElm = false;
	/** check casting in return statement */
	boolean casting = false;
	/** check return a const */
	boolean returnConst = false;

	int tempLoad;
	int temStore;

	public MethodCollector2(final MethodVisitor mv, String name, String desc) {
		super(ASM5, mv);
		this.mName = name;
		this.desc = desc;
		tempVar = 0;
		tempLocal = 0;
		tempStack = 0;
		isFieldAccess = false;
		fieldName = "";
		fieldOwner = "";
		fieldDesc = "";
		assignTaintedMethod();
	}

	public void visitCode() {
		if (!mName.contains(".phosphor.") && !mName.contains("java.") && !mName.contains("sun.")
				&& !mName.contains("maven.") &&  !mName.contains("junit")) {
//			print(mName);
		}
		super.visitCode();
	}

	private void print(String content) {
		mv.visitFieldInsn(GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
		mv.visitLdcInsn(content);
		mv.visitMethodInsn(INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V", false);
	}

	@Override
	public void visitMaxs(int maxStack, int maxLocals) {
		if (mName.contains("<clinit>"))
			tempLocal = 0;
		super.visitMaxs(maxStack + tempStack, maxLocals + tempLocal);
	}

	//
	@Override
	public void visitInsn(int opcode) {
		if (!mName.contains(".phosphor.") && !mName.contains("java.") && !mName.contains("sun.")
				&& !mName.contains("maven.") &&  !mName.contains("junit")) {
			if (opcode == ACONST_NULL)
				returnNull = true;
			if (opcode == AALOAD)
				returnArrElm = true;
			if (!returnNull && opcode >= IRETURN && opcode <= ARETURN) {
				/* Taint output */
				// Field access
				if (isFieldAccess) {
					if (taintedMethodDesc.isEmpty()) {
						if (TAIN_OBJECT)
							accessFieldObj();
						print("Return object: " + mName);
					} else {
						taintPrimitive();
					}
					// Normal cases
				} else {
					if (!taintedMethodDesc.isEmpty()) {
						taintPrimitive();
					} else {
						if (TAIN_OBJECT) {
							if (!returnArrElm && !casting && !returnConst && !returnNewInstance) {
								// TODO: handle the case of returning an element of an array
								if (this.tempLocal == 1) {
									// TODO: Handle return new instance
									tempVar = tempVar + 1;
									tempStack = 2;
									mv.visitVarInsn(ASTORE, tempVar);
									mv.visitVarInsn(ALOAD, tempVar);
								}
								taintObject();
								mv.visitVarInsn(ALOAD, tempVar);
							}
						}
						print("Return object: " + mName);
					}
				}
			}
			if (opcode == RETURN) {
				print("Void: " + mName);
			}
			// ternary = false;
			returnConst = false;
			casting = false;
			returnNewInstance = false;
		}
		super.visitInsn(opcode);
	}

	private void accessFieldObj() {
		taintObject();
		tempVar = tempVar - 1;
		if (!isFieldStatic) {
			//Load this
			mv.visitVarInsn(ALOAD, 0);
			mv.visitFieldInsn(GETFIELD, fieldOwner, fieldName, fieldDesc);
		} else
			mv.visitFieldInsn(GETSTATIC, fieldOwner, fieldName, fieldDesc);
		tempStack = 3;
	}

	private void taintPrimitive() {
		mv.visitLdcInsn(mName);
		mv.visitMethodInsn(INVOKESTATIC, "edu/columbia/cs/psl/phosphor/runtime/MultiTainter", taintedMethod,
				taintedMethodDesc, false);
		print("Return: " + mName);
	}

	private void taintObject() {
		mv.visitTypeInsn(NEW, "edu/columbia/cs/psl/phosphor/runtime/Taint");
		mv.visitInsn(DUP);
		mv.visitLdcInsn(mName);
		mv.visitMethodInsn(INVOKESPECIAL, "edu/columbia/cs/psl/phosphor/runtime/Taint", "<init>",
				"(Ljava/lang/Object;)V", false);
		mv.visitMethodInsn(INVOKESTATIC, "edu/columbia/cs/psl/phosphor/runtime/MultiTainter", "taintedObject",
				"(Ljava/lang/Object;Ledu/columbia/cs/psl/phosphor/runtime/Taint;)V", false);
	}

	@Override
	public void visitVarInsn(int opcode, int var) {
		if (opcode == ALOAD)
			this.tempVar = var;
		this.tempLocal = 0;
		isFieldAccess = false;
		returnNull = false;
		// ternary = false;
		returnArrElm = false;
		returnConst = false;
		returnNewInstance = false;
		super.visitVarInsn(opcode, var);
	}

	@Override
	public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf) {
		this.tempLocal = 1;
		isFieldAccess = false;
		returnNull = false;
		// ternary = false;
		returnArrElm = false;
		returnConst = false;
		returnNewInstance = false;
		if (name.equals("<init>")) {
			returnNewInstance = true;
		}
		super.visitMethodInsn(opcode, owner, name, desc, itf);
	}

	private void assignTaintedMethod() {
		String defult = "Ljava/lang/Object;";
		int start = desc.indexOf(")") + 1;
		String temp = desc.substring(start, desc.length()).trim();
		taintedMethodDesc = "(" + temp + defult + ")" + temp;
		switch (temp) {
		case "I":
			taintedMethod = "taintedInt";
			break;
		case "S":
			taintedMethod = "taintedShort";
			break;
		case "J":
			taintedMethod = "taintedLong";
			break;
		case "D":
			taintedMethod = "taintedDouble";
			break;
		case "Z":
			taintedMethod = "taintedBoolean";
			break;
		case "C":
			taintedMethod = "taintedChar";
			break;
		case "B":
			taintedMethod = "taintedByte";
			break;
		case "F":
			taintedMethod = "taintedFloat";
			break;
		case "[I":
			taintedMethod = "taintedIntArray";
			break;
		case "[F":
			taintedMethod = "taintedFloatArray";
			break;
		case "[D":
			taintedMethod = "taintedDoubleArray";
			break;
		case "[Z":
			taintedMethod = "taintedBooleanArray";
			break;
		case "[C":
			taintedMethod = "taintedCharArray";
			break;
		case "[J":
			taintedMethod = "taintedLongArray";
			break;
		case "[B":
			taintedMethod = "taintedByteArray";
			break;
		case "[S":
			taintedMethod = "taintedShortArray";
			break;
		default:
			taintedMethodDesc = "";
			taintedMethod = "taintedObject";
			break;
		}
	}

	@Override
	public void visitFieldInsn(int opcode, String owner, String name, String desc) {
		if (opcode == GETFIELD || opcode == GETSTATIC) {
			isFieldAccess = true;
			this.fieldName = name;
			this.fieldDesc = desc;
			this.fieldOwner = owner;
			isFieldStatic = false;
		}
		if (opcode == GETSTATIC) {
			isFieldStatic = true;
		}
		returnNull = false;
		returnArrElm = false;
		returnConst = false;
		returnNewInstance = false;
		// ternary = false;
		super.visitFieldInsn(opcode, owner, name, desc);
	}

	@Override
	public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {
		super.visitFrame(type, nLocal, local, nStack, stack);
		// ternary = true;
	}

	@Override
	public void visitTypeInsn(int opcode, String type) {
		casting = true;
		if (taintedMethodDesc.isEmpty()) {
			// TODO casting
			// taintObject();
			// mv.visitVarInsn(ALOAD, tempVar);
		}
		super.visitTypeInsn(opcode, type);
	}

	@Override
	public void visitLdcInsn(Object cst) {
		returnConst = true;
		super.visitLdcInsn(cst);
	}

}