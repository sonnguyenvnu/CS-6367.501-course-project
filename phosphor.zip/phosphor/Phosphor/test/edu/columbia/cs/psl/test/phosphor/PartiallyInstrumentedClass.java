package edu.columbia.cs.psl.test.phosphor;

public class PartiallyInstrumentedClass {
	
	public PartiallyInstrumentedClass()
	{
		
	}
	public PartiallyInstrumentedClass(int in)
	{
		
	}
	public PartiallyInstrumentedClass(int[][][] mdin)
	{
		
	}
	public static void foo(){
		
	}
	public static void inst(int a)
	{
		
	}
	public static boolean uninst(){
		return false;
	}

}
