package edu.columbia.cs.psl.phosphor.ds;

import org.junit.Test;

public class ControlTaintTagTest {
	@Test
	public void testAddControlTag() throws Exception {
//		Taint tag = new Taint("a");
//		Taint tag3 = new Taint("a3");
//
//		Taint tag2 = new Taint("a2");
//		ControlTaintTagStack ctrl = new ControlTaintTagStack();
//		Taint tag5 = new Taint(tag2);
//		tag = ctrl.push(tag);
//		tag3 = ctrl.push(tag3);
//		tag2 = ctrl.push(tag2);
//		ctrl.push(tag5);
//		System.out.println("..."+ctrl.taint);
//		Taint a = ctrl.copyTag();
//		ctrl.push(a);
//		System.out.println(">>>"+ctrl.taint);
//		
//		Taint b = Taint.combineTags(a, ctrl.taint);
//		ctrl.push(b);
//		System.out.println("zzz"+b);
//
//		System.out.println(">>>"+ctrl.taint);
//		
//		ctrl.pop(tag);
//		System.out.println(ctrl.taint);
//		ctrl.push(b);
//		System.out.println(">>>"+ctrl.taint);
//		ctrl.pop(tag2);
//		System.out.println(ctrl.taint);
//		ctrl.pop(tag3);
//		System.out.println(ctrl.taint);
//		System.out.println("Enqueued:");
//		System.out.println(tag.enqueuedInControlFlow);

	}
}
