package edu.columbia.cs.psl.phosphor.struct;

public interface TaintedBooleanWithIntTag {

}
